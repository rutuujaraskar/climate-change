Hi,
Myself Sushir Dhananjay N. 
I am very glad to Design and Develope this weather forcasting web application.
This retrieves a 7-day weather forecast from the Open Weather API.
Uses HTML,CSS and JavaScript.